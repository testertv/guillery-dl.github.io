﻿Imports System.IO

Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox2.Text = Application.StartupPath

        '----------------------- create options file if not exist --------------
        If Not System.IO.File.Exists(Application.StartupPath & "\options.ini") Then                       'if options file not exist
            File.Create(Application.StartupPath & "\options.ini").Dispose()                               'create options file
            Dim createText() As String = {"", "", ""}                                                     ' write empty lines in options file
            System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", createText)
        End If

        '---------------------- save new options ------------------------------
        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\options.ini")
        If Lines(0) = "" Then Lines(0) = TextBox2.Text
        If Lines(0) <> "" Then TextBox2.Text = Lines(0)

        If Lines(1) = "" Then Lines(1) = 0
        If Lines(1) <> "" Then ComboBox1.SelectedIndex = Lines(1)

        System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", Lines)

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        '########################################################################################
        '###############################   Choose output folder  ################################
        '########################################################################################
        If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
            TextBox2.Text = FolderBrowserDialog1.SelectedPath
        End If

        '----------- change options file --------------------
        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\options.ini")
        Lines(0) = TextBox2.Text
        System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", Lines)

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        '########################################################################################
        '################################   Open output folder  #################################
        '########################################################################################
        Process.Start(TextBox2.Text)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        '########################################################################################
        '############   Clear Textbox (Link) | Paste Link from clipboard to textbox  ############
        '########################################################################################
        TextBox1.Text = ""
        TextBox1.ForeColor = Color.Black
        Me.TextBox1.Paste()
    End Sub
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        '########################################################################################
        '###################################  (Un)pin window  ###################################
        '########################################################################################

        If Me.TopMost = True Then
            Me.TopMost = False
            Button5.BackColor = System.Drawing.SystemColors.Control
            Button5.Text = "Pin"
        Else
            Me.TopMost = True
            Button5.BackColor = Color.White
            Button5.Text = "Unpin"
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        About.Show()
    End Sub

    Private Sub TextBox1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.Click
        '########################################################################################
        '############################   Remove temp-links on click  #############################
        '########################################################################################
        If TextBox1.Text = "Media link to download..." Then
            TextBox1.Text = ""
            TextBox1.ForeColor = Color.Black
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        '########################################################################################
        '############################   Save current status of combobox  ########################
        '########################################################################################

        '----------- change options file --------------------
        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\options.ini")

        If ComboBox1.SelectedIndex = 0 Then
            Lines(1) = 0
        ElseIf ComboBox1.SelectedIndex = 1 Then
            Lines(1) = 1
        End If

        System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", Lines)

    End Sub

    '########################################################################################
    '###################################   Download media  ##################################
    '########################################################################################

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        '########################################################################################
        '#####################   Check internet connection | Link   #############################
        '########################################################################################
        If My.Computer.Network.IsAvailable = False Then
            TextBox3.Text = "No internet connection available!"
            TextBox3.Visible = True
            Exit Sub
        End If

        '########################################################################################
        '############################   Stop youtube-dl or ffmpeg   #############################
        '########################################################################################

        For Each p As Process In Process.GetProcesses
            If p.ProcessName = "youtube-dl" Or p.ProcessName = "cmd" Or p.ProcessName = "gallery-dl" Or p.ProcessName = "ffmpeg" Then
                CloseAll()                                  'close all programs
                TextBox3.Text = "Process stoped"
                Button2.Text = "Download"
                Exit Sub
            End If

        Next


        '########################################################################################
        '##################################   Download   ########################################
        '########################################################################################

        TextBox3.Text = "Download started!"
        TextBox3.Refresh()
        Button2.Text = "Stop"

        If TextBox1.Text = "" Then Exit Sub
        On Error Resume Next
        System.IO.Directory.Delete(Application.StartupPath & "\gallery-dl", True)     'Remove old folders

        '------------------------------ download media ---------------------------------

        Dim CMDcommand As String = "gallery-dl " & TextBox1.Text & " && echo done"

        Download_Process = New Process

        With Download_Process.StartInfo
            .FileName = "cmd"
            .RedirectStandardError = True
            .RedirectStandardInput = True
            .RedirectStandardOutput = True
            .CreateNoWindow = True
            .UseShellExecute = False
        End With

        Download_Process.Start()
        Download_Process.StandardInput.WriteLine("cls")
        Download_Process.StandardInput.WriteLine("cd " & Application.StartupPath)
        Download_Process.StandardInput.WriteLine(CMDcommand)
        Download_Process.StandardInput.WriteLine("exit")

        Download_Process.BeginErrorReadLine()
        Download_Process.BeginOutputReadLine()



    End Sub

    Private Sub p_OutputDataReceived(ByVal sender As Object, ByVal e As DataReceivedEventArgs) Handles Download_Process.OutputDataReceived
        Me.Invoke(New WriteA(AddressOf Write), e.Data & Environment.NewLine)
    End Sub

    Private Sub p_ErrorDataReceived(ByVal sender As Object, ByVal e As DataReceivedEventArgs) Handles Download_Process.ErrorDataReceived
        Me.Invoke(New WriteA(AddressOf Write), e.Data & Environment.NewLine)
    End Sub

    Private Sub Write(ByVal Line As String)
        '########################################################################################
        '#######################   Status line (textfield) update  ############################
        '########################################################################################

        If Line.Contains(".\gallery-dl") Then
            TextBox3.Text = Line
        ElseIf Line.Contains("HTTP redirect") Then
CloseAll()
            TextBox3.Text = "Web page banned you! Please reconnect you internet connection or use VPN!"
            Exit Sub
        ElseIf Line.Contains("error") Then
CloseAll()
            TextBox3.Text = "Wrong link!"
            Exit Sub
        End If

        If Line.Contains("done") Then

            If Line.Contains("echo done") Then
            Else

                '########################################################################################
                '###########################   Replace downloaded media  ################################
                '########################################################################################

                '------------------------------ find last folder path ---------------------------------
                Dim direction As DirectoryInfo = New DirectoryInfo(Application.StartupPath & "\gallery-dl")
                Dim directories() As DirectoryInfo = direction.GetDirectories("*", SearchOption.AllDirectories)
                Dim ListOfEmptyDirectory As New List(Of String)
                For Each dir As DirectoryInfo In directories
                    If dir.GetDirectories("*", SearchOption.AllDirectories).Count = 0 Then

                        '---------------------------- Replace downloaded media --------------------------
                        If ComboBox1.SelectedIndex = 0 Then     'only media files
                            For Each FileToMove In My.Computer.FileSystem.GetFiles(dir.FullName, FileIO.SearchOption.SearchTopLevelOnly)
                                Dim FileToMoveName = My.Computer.FileSystem.GetName(FileToMove)
                                My.Computer.FileSystem.MoveFile(FileToMove, My.Computer.FileSystem.CombinePath(TextBox2.Text, FileToMoveName), overwrite:=True)
                            Next
                        ElseIf ComboBox1.SelectedIndex = 1 Then     'media files and profil folder

                            Dim LastIndex As Integer = dir.FullName.LastIndexOf("\")            'find last char of path
                            Dim Path As String = dir.FullName.Substring(0, LastIndex)           'path of folder

                            My.Computer.FileSystem.MoveDirectory(Path, TextBox2.Text, True)           ' move folder to wish ditination
                        End If

                    End If
                Next


                TextBox3.Text = "Download finished!"
                Button2.Text = "Download"
                CloseAll()
            End If

        End If

    End Sub
    Private Sub CloseAll()
        '########################################################################################
        '#######################   Close all CMD and Gallery-Dl windows  ########################
        '########################################################################################
        Download_Process.Start()
        Download_Process.StandardInput.WriteLine("taskkill /im cmd.exe /t /f && taskkill /im gallery-dl.exe /t /f && taskkill /im youtube-dl.exe /t /f && taskkill /im ffmpeg.exe /t /f ")
        Download_Process.StandardInput.WriteLine("exit")
    End Sub

    Private variable As String = 0
    Private WithEvents Download_Process As Process
    Private Delegate Sub WriteA(ByVal Text As String)

End Class
